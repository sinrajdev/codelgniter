<?php
// print_r($details);
// die; 
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
</head>
<style>
    .row {
        margin-top: 40px;
        padding: 0 10px;
    }

    .clickable {
        cursor: pointer;
    }

    .panel-heading div {
        margin-top: -18px;
        font-size: 15px;
    }

    .panel-heading div span {
        margin-left: 5px;
    }

    .panel-body {
        display: none;
    }
</style>

<body>

    <!------ Include the above in your HEAD tag ---------->

    <div class="container">
        <h1>Click the filter icon <small>(<i class="glyphicon glyphicon-filter"></i>)</small></h1>
        <div class="row">
            <div style="float: right; margin:40px;">
                <a href="<?php echo base_url() . 'createform' ?>"><button class="btn-primary"style="width: 150%;height:30px">Add</button></a>
            </div><br>
            <div class="col-md-12">
                <div class="panel panel-success">

                    <div class="panel-heading">
                        <h3 class="panel-title">Tasks</h3>
                        <div class="pull-right">
                            <span class="clickable filter" data-toggle="tooltip" title="Toggle table filter" data-container="body">
                                <i class="glyphicon glyphicon-filter"></i>
                            </span>
                        </div>
                    </div>
                    <div class="panel-body">
                        <input type="text" class="form-control" id="task-table-filter" data-action="filter" data-filters="#task-table" placeholder="Filter Tasks" />
                    </div>
                    <table class="table table-hover" id="task-table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Gender</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $count = 1;
                            foreach ($details as $val) :
                            ?>
                                <tr>
                                    <td><?php echo $count ?></td>
                                    <td><?php echo $val['name'] ?></td>
                                    <td><?php echo $val['email'] ?></td>
                                    <td><?php echo $val['gender'] ?></td>
                                    <td>
                                        <a href="<?php echo base_url() . 'editdata/' . $val['id'] ?>"> <button>Update</button></a>&nbsp;
                                        <a href="<?php echo base_url() . 'deletedata/' . $val['id'] ?>"><button>Delete</button></a>
                                    </td>
                                </tr>

                            <?php
                                $count++;
                            endforeach
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script>
        /**
         *   I don't recommend using this plugin on large tables, I just wrote it to make the demo useable. It will work fine for smaller tables 
         *   but will likely encounter performance issues on larger tables.
         *
         *		<input type="text" class="form-control" id="dev-table-filter" data-action="filter" data-filters="#dev-table" placeholder="Filter Developers" />
         *		$(input-element).filterTable()
         *		
         *	The important attributes are 'data-action="filter"' and 'data-filters="#table-selector"'
         */
        (function() {
            'use strict';
            var $ = jQuery;
            $.fn.extend({
                filterTable: function() {
                    return this.each(function() {
                        $(this).on('keyup', function(e) {
                            $('.filterTable_no_results').remove();
                            var $this = $(this),
                                search = $this.val().toLowerCase(),
                                target = $this.attr('data-filters'),
                                $target = $(target),
                                $rows = $target.find('tbody tr');

                            if (search == '') {
                                $rows.show();
                            } else {
                                $rows.each(function() {
                                    var $this = $(this);
                                    $this.text().toLowerCase().indexOf(search) === -1 ? $this.hide() : $this.show();
                                })
                                if ($target.find('tbody tr:visible').size() === 0) {
                                    var col_count = $target.find('tr').first().find('td').size();
                                    var no_results = $('<tr class="filterTable_no_results"><td colspan="' + col_count + '">No results found</td></tr>')
                                    $target.find('tbody').append(no_results);
                                }
                            }
                        });
                    });
                }
            });
            $('[data-action="filter"]').filterTable();
        })(jQuery);

        $(function() {
            // attach table filter plugin to inputs
            $('[data-action="filter"]').filterTable();

            $('.container').on('click', '.panel-heading span.filter', function(e) {
                var $this = $(this),
                    $panel = $this.parents('.panel');

                $panel.find('.panel-body').slideToggle();
                if ($this.css('display') != 'none') {
                    $panel.find('.panel-body input').focus();
                }
            });
            $('[data-toggle="tooltip"]').tooltip();
        })
    </script>
</body>

</html>