<?php
// print_r($) 
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/css/bootstrap-combined.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
</head>

<body>

    <!------ Include the above in your HEAD tag ---------->

    <div class="span3">
        <h2>Sign Up</h2>
        <form action="<?php echo base_url() . 'updateformdata' ?>" method="post">
            <input type="hidden" name="id" value="<?php echo $updatedata['id'] ?>">
            <label>Name</label>
            <input type="text" name="name" value="<?php echo $updatedata['name'] ?>" class="span3">

            <label>Email Address</label>
            <input type="email" name="email" value="<?php echo $updatedata['email'] ?>" class="span3">

            <label>Gender</label>
            <select name="gender">
                <option value="male"<?php 
                    if($updatedata['gender'] == 'male'){
                        echo 'Selected';

                    }
                ?>>male</option>
                <option value="female"
                <?php  if($updatedata['gender'] == 'female'){
                        echo 'Selected';

                    }?>
                >female</option>
            </select>
            <button>Submit</button>
            <div class="clearfix"></div>
        </form>
    </div>
</body>

</html>