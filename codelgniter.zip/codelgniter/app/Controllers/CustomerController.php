<?php

namespace App\Controllers;

use App\Models\CustomerModel;

class CustomerController extends BaseController
{
    public function index()
    {


        // $data = [];
        // $blogmodel = new BlogModel();
        // $data['details'] = $blogmodel->getdata();

        // return view('list',$data);

        $data = [];
        $CustomerModel = new CustomerModel();
        $data['details'] = $CustomerModel->getdata();


        return view('list', $data);
    }

    public function create()
    {
        return view('create');
    }

    public function createdata()
    {


        $data = [
            'name' => $this->request->getVar('name'),
            'email' => $this->request->getVar('email'),
            'gender' => $this->request->getVar('gender')
        ];
        // print_r($data);
        // die;
        $customerModel = new CustomerModel();
        $insert = $customerModel->createdata($data);
        if ($insert) {
            return redirect()->to('/');
        } else {
            return redirect()->to('/');;
        }
    }

    public function updateform($id)
    {


        $CustomerModel = new CustomerModel();
        $data['updatedata'] = $CustomerModel->getdataByid($id);
        // print_r($data['updatedata']);
        // die;
        return view('updateform', $data);
    }


    public function update()
    {
        $id = $this->request->getVar('id');
        $data = [
            'name' => $this->request->getVar('name'),
            'email' => $this->request->getVar('email'),
            'gender' => $this->request->getVar('gender')
        ];
        //   print_r($data);
        //   die;
        $CustomerModel = new CustomerModel();
        $update = $CustomerModel->update1($id, $data);

        if ($update) {
            // $session->setFlashdata('success', 'Category deleted');
            return redirect()->to('/');
        } else {
            // $session->setFlashdata('error', 'Category not deleted');
            return redirect()->to('/');
        }
    }


    public function delete($id)
    {
        $customerModel = new CustomerModel();
        $delete =  $customerModel->delete1($id);

        if ($delete) {
            // $session->setFlashdata('success', 'Category deleted');
            return redirect()->to('/');
        } else {
            // $session->setFlashdata('error', 'Category not deleted');
            return redirect()->to('/');
        }
    }
}
